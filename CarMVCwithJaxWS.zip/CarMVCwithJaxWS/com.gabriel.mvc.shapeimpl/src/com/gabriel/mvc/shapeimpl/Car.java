package com.gabriel.mvc.shapeimpl;
import com.gabriel.mvc.shapesfx.MyShape;
import com.gabriel.mvc.shapesfx.Location;

public class Car implements MyShape{
	
	CarBody body;
	Wheel frontWheel;
	Wheel backWheel;
	Location location;

	public CarBody getBody() {
		return body;
	}

	public void setBody(CarBody body) {
		this.body = body;
	}

	public Wheel getFrontWheel() {
		return frontWheel;
	}

	public void setFrontWheel(Wheel frontWheel) {
		this.frontWheel = frontWheel;
	}

	public Wheel getBackWheel() {
		return backWheel;
	}

	public void setBackWheel(Wheel backWheel) {
		this.backWheel = backWheel;
	}

	@Override
	public Location getLocation() {
		return location;
	}

	@Override
	public void setLocation(Location location) {
		this.location = location;		
	}
}
