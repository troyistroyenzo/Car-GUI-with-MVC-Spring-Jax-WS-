package com.gabriel.mvc.shapeimpl;

import com.gabriel.mvc.shapesfx.MyShape;
import com.gabriel.mvc.shapesfx.Renderer;

public class CarRenderer implements Renderer {

	@Override
	public void draw(Object context, MyShape shape) {
		Car car = (Car)shape;
		CarBody carBody = car.getBody();
		CarBodyRenderer carBodyRenderer = new CarBodyRenderer();
		carBodyRenderer.draw(context, carBody);
		Wheel frontWheel = car.getFrontWheel();
		WheelRenderer wheelRenderer = new WheelRenderer();
		wheelRenderer.draw(context, frontWheel);
		Wheel backWheel = car.getBackWheel();
		wheelRenderer.draw(context, backWheel);
	}

}
